// src/foods.js
const foods = [
    { name: 'Pasta', carbs: 25, protein: 5, fat: 1 },
    { name: 'Chicken', carbs: 0, protein: 31, fat: 3.6 },
    { name: 'Ground Beef', carbs: 0, protein: 26, fat: 20 },
    { name: 'Green Beans', carbs: 7, protein: 2, fat: 0.2 },
    // Ajoutez d'autres aliments ici
];

export default foods;
