import React, { createContext, useState } from 'react';

export const CalculationContext = createContext();

export const CalculationProvider = ({ children }) => {
    const [dailyIntake, setDailyIntake] = useState(null);

    return (
        <CalculationContext.Provider value={{ dailyIntake, setDailyIntake }}>
            {children}
        </CalculationContext.Provider>
    );
};
