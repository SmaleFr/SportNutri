import React, { useState, useContext, useEffect } from 'react';
import { CalculationContext } from '../CalculationContext';
import './NutritionPage.css';

const NutritionPage = () => {
    const { dailyIntake } = useContext(CalculationContext);
    const [selectedMeal, setSelectedMeal] = useState('');
    const [consumedFoods, setConsumedFoods] = useState({
        breakfast: [],
        lunch: [],
        dinner: [],
        snacks: [],
    });

    const foodDatabase = {
        'Pasta': { carbs: 25, protein: 5, fat: 1 },
        'Chicken': { carbs: 0, protein: 31, fat: 3.6 },
        'Ground Beef': { carbs: 0, protein: 26, fat: 20 },
        'Green Beans': { carbs: 7, protein: 2, fat: 0.1 },
    };

    useEffect(() => {
        const storedConsumedFoods = localStorage.getItem('consumedFoods');
        if (storedConsumedFoods) {
            setConsumedFoods(JSON.parse(storedConsumedFoods));
        }
    }, []);

    useEffect(() => {
        localStorage.setItem('consumedFoods', JSON.stringify(consumedFoods));
    }, [consumedFoods]);

    const handleAddFood = (mealType) => {
        if (selectedMeal && foodDatabase[selectedMeal]) {
            setConsumedFoods(prevState => ({
                ...prevState,
                [mealType]: [...prevState[mealType], selectedMeal]
            }));
            setSelectedMeal('');
        }
    };

    const calculateRemainingMacros = () => {
        let totalCarbs = 0;
        let totalProtein = 0;
        let totalFat = 0;

        Object.keys(consumedFoods).forEach(mealType => {
            consumedFoods[mealType].forEach(food => {
                if (foodDatabase[food]) {
                    totalCarbs += foodDatabase[food].carbs;
                    totalProtein += foodDatabase[food].protein;
                    totalFat += foodDatabase[food].fat;
                }
            });
        });

        if (!dailyIntake) {
            return {
                carbs: 0,
                protein: 0,
                fat: 0,
            };
        }

        return {
            carbs: dailyIntake.carbs - totalCarbs,
            protein: dailyIntake.protein - totalProtein,
            fat: dailyIntake.fat - totalFat,
        };
    };

    const remainingMacros = calculateRemainingMacros();

    return (
        <div className="nutrition-page">
            <h1>Nutrition Page</h1>
            <div>
                <label>Select Food:</label>
                <select value={selectedMeal} onChange={(e) => setSelectedMeal(e.target.value)}>
                    <option value="">Select</option>
                    {Object.keys(foodDatabase).map(food => (
                        <option key={food} value={food}>{food}</option>
                    ))}
                </select>
                <button onClick={() => handleAddFood('breakfast')}>Add to Breakfast</button>
                <button onClick={() => handleAddFood('lunch')}>Add to Lunch</button>
                <button onClick={() => handleAddFood('dinner')}>Add to Dinner</button>
                <button onClick={() => handleAddFood('snacks')}>Add to Snacks</button>
            </div>
            <div>
                <h2>Remaining Macros</h2>
                <p>Carbs: {remainingMacros.carbs}g</p>
                <p>Protein: {remainingMacros.protein}g</p>
                <p>Fat: {remainingMacros.fat}g</p>
            </div>
        </div>
    );
};

export default NutritionPage;
