import React from 'react';
import './HomePage.css';

function HomePage() {
    return (
        <div className="home-container">
            <h1>Welcome to SportNutri</h1>
            <p>Your personal nutrition and fitness tracker.</p>
        </div>
    );
}

export default HomePage;
