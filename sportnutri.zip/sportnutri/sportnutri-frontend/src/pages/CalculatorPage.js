import React, { useState, useEffect, useContext } from 'react';
import { CalculationContext } from '../CalculationContext';
import './CalculatorPage.css';

const CalculatorPage = () => {
    const { setDailyIntake } = useContext(CalculationContext);
    const [formValues, setFormValues] = useState({
        age: '',
        height: '',
        weight: '',
        activityLevel: '',
        goal: ''
    });

    useEffect(() => {
        const storedIntake = localStorage.getItem('dailyIntake');
        if (storedIntake) {
            setDailyIntake(JSON.parse(storedIntake));
        }
    }, [setDailyIntake]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormValues({ ...formValues, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const { age, height, weight, activityLevel, goal } = formValues;

        const bmr = 10 * weight + 6.25 * height - 5 * age + 5;
        const activityFactor = getActivityFactor(activityLevel);
        const goalFactor = getGoalFactor(goal);

        const dailyCalories = bmr * activityFactor * goalFactor;

        const dailyIntake = {
            calories: dailyCalories,
            carbs: dailyCalories * 0.5 / 4,
            protein: dailyCalories * 0.3 / 4,
            fat: dailyCalories * 0.2 / 9,
        };

        setDailyIntake(dailyIntake);
        localStorage.setItem('dailyIntake', JSON.stringify(dailyIntake));
    };

    const getActivityFactor = (activityLevel) => {
        switch (activityLevel) {
            case 'not_active': return 1.2;
            case 'slightly_active': return 1.375;
            case 'active': return 1.55;
            case 'very_active': return 1.725;
            default: return 1;
        }
    };

    const getGoalFactor = (goal) => {
        switch (goal) {
            case 'weight_loss': return 0.85;
            case 'maintenance': return 1;
            case 'weight_gain': return 1.15;
            default: return 1;
        }
    };

    return (
        <div className="calculator-page">
            <h1>Calculator Page</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    Age:
                    <input type="number" name="age" value={formValues.age} onChange={handleInputChange} required />
                </label>
                <label>
                    Height (cm):
                    <input type="number" name="height" value={formValues.height} onChange={handleInputChange} required />
                </label>
                <label>
                    Weight (kg):
                    <input type="number" name="weight" value={formValues.weight} onChange={handleInputChange} required />
                </label>
                <label>
                    Activity Level:
                    <select name="activityLevel" value={formValues.activityLevel} onChange={handleInputChange} required>
                        <option value="">Select</option>
                        <option value="not_active">Not Active</option>
                        <option value="slightly_active">Slightly Active</option>
                        <option value="active">Active</option>
                        <option value="very_active">Very Active</option>
                    </select>
                </label>
                <label>
                    Goal:
                    <select name="goal" value={formValues.goal} onChange={handleInputChange} required>
                        <option value="">Select</option>
                        <option value="weight_loss">Weight Loss</option>
                        <option value="maintenance">Maintenance</option>
                        <option value="weight_gain">Weight Gain</option>
                    </select>
                </label>
                <button type="submit">Calculate</button>
            </form>
        </div>
    );
};

export default CalculatorPage;
