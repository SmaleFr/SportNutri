import React, { useState, useEffect, useContext } from 'react';
import { CalculationContext } from '../CalculationContext';
import { Line } from 'react-chartjs-2';
import 'chart.js/auto';
import './ProgressPage.css';

const ProgressPage = () => {
    const { dailyIntake } = useContext(CalculationContext);
    const [weightEntries, setWeightEntries] = useState([]);
    const [newWeight, setNewWeight] = useState('');
    const [foodEntries, setFoodEntries] = useState([]);
    const [newFood, setNewFood] = useState('');

    useEffect(() => {
        const storedWeightEntries = localStorage.getItem('weightEntries');
        const storedFoodEntries = localStorage.getItem('foodEntries');
        if (storedWeightEntries) {
            setWeightEntries(JSON.parse(storedWeightEntries));
        }
        if (storedFoodEntries) {
            setFoodEntries(JSON.parse(storedFoodEntries));
        }
    }, []);

    useEffect(() => {
        localStorage.setItem('weightEntries', JSON.stringify(weightEntries));
    }, [weightEntries]);

    useEffect(() => {
        localStorage.setItem('foodEntries', JSON.stringify(foodEntries));
    }, [foodEntries]);

    const handleAddWeight = () => {
        const date = new Date().toLocaleDateString();
        setWeightEntries(prevEntries => [...prevEntries, { date, weight: newWeight }]);
        setNewWeight('');
    };

    const handleAddFood = () => {
        const date = new Date().toLocaleDateString();
        setFoodEntries(prevEntries => [...prevEntries, { date, food: newFood }]);
        setNewFood('');
    };

    const weightData = {
        labels: weightEntries.map(entry => entry.date),
        datasets: [
            {
                label: 'Weight (kg)',
                data: weightEntries.map(entry => entry.weight),
                fill: false,
                backgroundColor: 'blue',
                borderColor: 'blue',
            },
        ],
    };

    return (
        <div className="progress-page">
            <h1>Progress Page</h1>

            <div className="weight-section">
                <h2>Weight Tracking</h2>
                <input
                    type="number"
                    placeholder="Enter your weight"
                    value={newWeight}
                    onChange={(e) => setNewWeight(e.target.value)}
                />
                <button onClick={handleAddWeight}>Add Weight</button>
                <Line data={weightData} />
            </div>

            <div className="food-section">
                <h2>Food Journal</h2>
                <input
                    type="text"
                    placeholder="Enter food consumed"
                    value={newFood}
                    onChange={(e) => setNewFood(e.target.value)}
                />
                <button onClick={handleAddFood}>Add Food</button>
                <ul>
                    {foodEntries.map((entry, index) => (
                        <li key={index}>{entry.date}: {entry.food}</li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default ProgressPage;
