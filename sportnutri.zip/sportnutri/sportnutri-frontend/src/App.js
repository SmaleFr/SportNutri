import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './pages/HomePage';
import CalculatorPage from './pages/CalculatorPage';
import ProgressPage from './pages/ProgressPage';
import NutritionPage from './pages/NutritionPage';
import Chatbot from './components/Chatbot';
import Navbar from './components/Navbar';
import { CalculationProvider } from './CalculationContext';

function App() {
    return (
        <CalculationProvider>
            <Router>
                <Navbar />
                <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/calculator" element={<CalculatorPage />} />
                    <Route path="/progress" element={<ProgressPage />} />
                    <Route path="/nutrition" element={<NutritionPage />} />
                    <Route path="/chatbot" element={<Chatbot />} />
                </Routes>
            </Router>
        </CalculationProvider>
    );
}

export default App;
