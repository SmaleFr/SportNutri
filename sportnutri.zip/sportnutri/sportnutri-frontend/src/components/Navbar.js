import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css'; // Assurez-vous d'avoir les styles pour la barre de navigation
import logo from '../assets/images/logo.png'; // Importez le logo

const Navbar = () => {
    return (
        <nav className="navbar">
            <div className="navbar-logo">
                <Link to="/">
                    <img src={logo} alt="Logo" className="logo" />
                </Link>
            </div>
            <div className="navbar-links">
                <Link to="/">Home</Link>
                <Link to="/calculator">Calculator</Link>
                <Link to="/progress">Progress</Link>
                <Link to="/nutrition">Nutrition</Link>
                <Link to="/chatbot">Chatbot</Link>
            </div>
        </nav>
    );
}

export default Navbar;
