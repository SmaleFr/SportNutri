import React, { useState } from 'react';
import axios from 'axios';
import './Chatbot.css';

const Chatbot = () => {
    const [message, setMessage] = useState('');
    const [response, setResponse] = useState('');

    const handleSend = async () => {
        try {
            const res = await axios.post('http://localhost:5001/api/chatbot', { message });  // Changez ici le port si nécessaire
            setResponse(res.data.reply);
        } catch (error) {
            console.error('Error communicating with chatbot:', error);
            setResponse('Sorry, there was an error. Please try again.');
        }
    };

    return (
        <div>
            <h2>Chatbot</h2>
            <input 
                type="text" 
                value={message} 
                onChange={(e) => setMessage(e.target.value)} 
            />
            <button onClick={handleSend}>Send</button>
            <div>
                <h3>Response:</h3>
                <p>{response}</p>
            </div>
        </div>
    );
};

export default Chatbot;
