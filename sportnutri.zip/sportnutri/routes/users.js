// routes/users.js
const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Register route
router.post('/register', async (req, res) => {
    // Registration logic
});

// Login route
router.post('/login', async (req, res) => {
    // Login logic
});

module.exports = router;