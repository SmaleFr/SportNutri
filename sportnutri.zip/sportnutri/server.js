const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 5001;  // Changez ici le port par défaut

app.use(bodyParser.json());

app.post('/api/chatbot', async (req, res) => {
    const { message } = req.body;

    try {
        const response = await axios.post('https://api.together.ai/chat', {
            message: message,
            apiKey: process.env.TOGETHER_AI_API_KEY
        });

        res.json(response.data);
    } catch (error) {
        console.error('Error communicating with Together AI:', error);
        res.status(500).json({ error: 'Error communicating with Together AI' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
